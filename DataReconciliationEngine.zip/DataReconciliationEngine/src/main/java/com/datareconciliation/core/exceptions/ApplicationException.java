package com.datareconciliation.core.exceptions;

public class ApplicationException extends Exception {

	private static final long serialVersionUID = 1L;
	String msg;
	public ApplicationException(String msg){
		super(msg);
		this.msg = msg;
	}
	
}
